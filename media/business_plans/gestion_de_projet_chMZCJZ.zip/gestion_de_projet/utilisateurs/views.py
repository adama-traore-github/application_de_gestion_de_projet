from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm  # Assurez-vous d'importer le bon formulaire

# Vue pour le formulaire Admin
def admin_register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'admin'  # Attribuer le rôle Admin
            user.save()
            return redirect('home')  # Rediriger après inscription
    else:
        form = CustomUserCreationForm()
    return render(request, 'utilisateurs/admin_form.html', {'form': form})

# Vue pour le formulaire Utilisateur
def user_register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'user'  # Attribuer le rôle Utilisateur
            user.save()
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'utilisateurs/user_form.html', {'form': form})

# Vue pour le formulaire Partenaire
def partner_register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'partner'  # Attribuer le rôle Partenaire
            user.save()
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'utilisateurs/partner_form.html', {'form': form})
