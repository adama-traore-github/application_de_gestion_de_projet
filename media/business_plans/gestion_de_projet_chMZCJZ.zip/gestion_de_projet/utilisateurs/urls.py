from django.urls import path
from .views import home, admin_register, user_register, partner_register

urlpatterns = [
    path('', home, name='home'),  # Page de sélection du rôle
    path('admin_register/', admin_register, name='admin_register'),  # Formulaire pour Admin
    path('user_register/', user_register, name='user_register'),  # Formulaire pour Utilisateur
    path('partner_register/', partner_register, name='partner_register'),  # Formulaire pour Partenaire
]
