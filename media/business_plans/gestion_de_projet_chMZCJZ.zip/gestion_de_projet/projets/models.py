from django.db import models
from utilisateurs.models import User

class Projet(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    is_validated = models.BooleanField(default=False)
