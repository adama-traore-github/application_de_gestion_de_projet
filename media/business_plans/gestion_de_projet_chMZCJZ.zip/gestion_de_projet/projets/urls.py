from django.urls import path
from .views import submit_projet

urlpatterns = [
    path('submit/', submit_projet, name='submit_projet'),
]
