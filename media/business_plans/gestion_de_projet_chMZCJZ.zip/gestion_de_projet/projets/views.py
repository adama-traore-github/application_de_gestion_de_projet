from django.shortcuts import render, redirect
from .forms import ProjetForm

def submit_projet(request):
    if request.method == 'POST':
        form = ProjetForm(request.POST)
        if form.is_valid():
            projet = form.save(commit=False)
            projet.created_by = request.user
            projet.save()
            return redirect('project_list')  # Redirection vers la liste des projets
    else:
        form = ProjetForm()
    return render(request, 'projets/submit_projet.html', {'form': form})
