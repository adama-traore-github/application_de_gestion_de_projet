def inverser_tuple(tup):
    # Utilise la notation de slicing pour inverser le tuple
    return tup[::-1]

# Exemple d'utilisation
mon_tuple = (1, 2, 3, 4, 5)
tuple_inverse = inverser_tuple(mon_tuple)

# Affichage du résultat
print("Tuple original :", mon_tuple)
print("Tuple inversé :", tuple_inverse)
