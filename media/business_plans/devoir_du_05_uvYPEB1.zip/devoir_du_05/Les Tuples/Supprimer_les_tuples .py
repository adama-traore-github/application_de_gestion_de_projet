def supprimer_tuples_vides(liste):
    # Utilise une compréhension de liste pour filtrer les tuples non vides
    return [tuple for tuple in liste if tuple]

# Exemple d'utilisation
ma_liste = [(1, 2), (), (3, 4), (), (5,), ()]
liste_sans_vides = supprimer_tuples_vides(ma_liste)

# Affichage du résultat
print("Liste sans tuples vides :", liste_sans_vides)
