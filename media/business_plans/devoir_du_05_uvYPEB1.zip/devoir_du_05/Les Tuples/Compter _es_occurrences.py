def compter_occurrences(tup, element):
    # Utilise la méthode count pour compter les occurrences de l'élément dans le tuple
    return tup.count(element)

# Exemple d'utilisation
mon_tuple = (1, 2, 3, 4, 2, 5, 2)
element_a_compter = 2
nombre_occurrences = compter_occurrences(mon_tuple, element_a_compter)

# Affichage du résultat
print(f"L'élément {element_a_compter} apparaît {nombre_occurrences} fois dans le tuple.")
