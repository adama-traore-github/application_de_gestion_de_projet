def liste_tuples_en_dictionnaire(liste_tuples):
    # Utilise la fonction dict pour convertir la liste de tuples en dictionnaire
    return dict(liste_tuples)

# Exemple d'utilisation
ma_liste_tuples = [('a', 1), ('b', 2), ('c', 3)]
mon_dictionnaire = liste_tuples_en_dictionnaire(ma_liste_tuples)

# Affichage du résultat
print("Dictionnaire obtenu :", mon_dictionnaire)
