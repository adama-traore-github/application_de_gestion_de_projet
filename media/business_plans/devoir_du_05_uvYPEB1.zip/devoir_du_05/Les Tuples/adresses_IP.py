def est_ip_valide(ip):
    # Vérifie si une adresse IP est valide
    parties = ip.split('.')
    if len(parties) != 4:
        return False
    for partie in parties:
        if not partie.isdigit() or not 0 <= int(partie) <= 255:
            return False
        if len(partie) > 1 and partie[0] == '0':
            return False  # Évite les nombres avec un zéro initial
    return True

def generer_ips(s):
    # Fonction pour générer toutes les adresses IP valides à partir d'une chaîne
    n = len(s)
    adresses_ip = []

    # Parcourt toutes les positions pour insérer des points
    for i in range(1, min(4, n - 2)):  # 1 à 3 caractères pour la première partie
        for j in range(i + 1, min(i + 4, n - 1)):  # 1 à 3 caractères pour la deuxième partie
            for k in range(j + 1, min(j + 4, n)):  # 1 à 3 caractères pour la troisième partie
                # Construire l'adresse IP
                ip = f"{s[:i]}.{s[i:j]}.{s[j:k]}.{s[k:]}"
                if est_ip_valide(ip):
                    adresses_ip.append(ip)

    return adresses_ip

# Exemple d'utilisation
chaine = "25525511135"
adresses_ip_valides = generer_ips(chaine)

# Affichage des adresses IP valides
print("Adresses IP valides générées :")
for ip in adresses_ip_valides:
    print(ip)
