def trier_tuples(tuples_liste, index_cle):
    # Utilise la fonction sorted pour trier la liste de tuples par la clé spécifiée
    return sorted(tuples_liste, key=lambda x: x[index_cle])

# Exemple d'utilisation
ma_liste_tuples = [(1, 'Apple'), (3, 'Banana'), (2, 'Cherry'), (4, 'Date')]
index_a_trier = 0  # Trier par le premier élément de chaque tuple

tuples_tries = trier_tuples(ma_liste_tuples, index_a_trier)

# Affichage du résultat
print("Liste de tuples triée :", tuples_tries)
