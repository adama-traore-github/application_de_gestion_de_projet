def liste_en_chaine(liste):
    # Utilise la méthode join pour convertir la liste en chaîne
    return ''.join(liste)

# Exemple d'utilisation
ma_liste = ['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']
chaine_resultat = liste_en_chaine(ma_liste)

# Affichage du résultat
print("La chaîne de caractères est :", chaine_resultat)
