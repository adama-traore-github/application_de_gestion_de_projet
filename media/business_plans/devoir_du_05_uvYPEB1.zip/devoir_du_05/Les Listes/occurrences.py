def compter_occurrences(liste, element):
    # Compte le nombre d'occurrences de l'élément dans la liste
    return liste.count(element)

# Exemple d'utilisation
ma_liste = [1, 2, 3, 1, 4, 1, 5]
element_a_compter = 1

nombre_occurrences = compter_occurrences(ma_liste, element_a_compter)
print(f"L'élément {element_a_compter} apparaît {nombre_occurrences} fois dans la liste.")
