def calculer_somme_et_moyenne(liste):
    # Vérifie si la liste est vide
    if not liste:
        return 0, 0

    # Calcule la somme
    somme = sum(liste)
    
    # Calcule la moyenne
    moyenne = somme / len(liste)

    return somme, moyenne

# Exemple d'utilisation
ma_liste = [10, 20, 30, 40, 50]

somme, moyenne = calculer_somme_et_moyenne(ma_liste)
print(f"La somme des éléments de la liste est : {somme}")
print(f"La moyenne des éléments de la liste est : {moyenne}")
