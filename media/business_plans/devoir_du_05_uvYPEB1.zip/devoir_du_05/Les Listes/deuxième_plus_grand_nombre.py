def trouver_deuxieme_plus_grand(liste):
    # Vérifie si la liste a moins de deux éléments
    if len(liste) < 2:
        return None  # Retourne None si la liste a moins de deux éléments

    # Initialisation des deux plus grands nombres
    premier = deuxieme = float('-inf')

    # Parcourt la liste pour trouver le premier et le deuxième plus grand
    for nombre in liste:
        if nombre > premier:
            deuxieme = premier  # Met à jour le deuxième plus grand
            premier = nombre  # Met à jour le premier plus grand
        elif premier > nombre > deuxieme:
            deuxieme = nombre  # Met à jour le deuxième plus grand

    return deuxieme if deuxieme != float('-inf') else None

# Exemple d'utilisation
ma_liste = [34, 12, 5, 78, 23, 78]

deuxieme_plus_grand_nombre = trouver_deuxieme_plus_grand(ma_liste)

# Affichage du résultat
if deuxieme_plus_grand_nombre is not None:
    print(f"Le deuxième plus grand nombre dans la liste est : {deuxieme_plus_grand_nombre}")
else:
    print("Il n'y a pas suffisamment d'éléments distincts dans la liste.")
