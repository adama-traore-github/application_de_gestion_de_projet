def trouver_plus_grand(liste):
    # Vérifie si la liste est vide
    if not liste:
        return None  # Retourne None si la liste est vide

    # Initialise le plus grand nombre avec le premier élément de la liste
    plus_grand = liste[0]

    # Parcourt la liste pour trouver le plus grand nombre
    for nombre in liste:
        if nombre > plus_grand:
            plus_grand = nombre

    return plus_grand

# Exemple d'utilisation
ma_liste = [34, 12, 5, 78, 23]

plus_grand_nombre = trouver_plus_grand(ma_liste)

# Affichage du résultat
print(f"Le plus grand nombre dans la liste est : {plus_grand_nombre}")
