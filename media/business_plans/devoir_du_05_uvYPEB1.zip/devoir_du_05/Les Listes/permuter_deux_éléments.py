def permuter_elements(liste, index1, index2):
    # Vérifie si les indices sont valides
    if index1 < 0 or index1 >= len(liste) or index2 < 0 or index2 >= len(liste):
        return "Indices non valides"

    # Affiche la liste avant la permutation
    print("Avant permutation :", liste)

    # Permute les éléments
    liste[index1], liste[index2] = liste[index2], liste[index1]

    # Affiche la liste après la permutation
    print("Après permutation :", liste)

# Exemple d'utilisation
ma_liste = [10, 20, 30, 40, 50]
permuter_elements(ma_liste, 1, 3)  # Permute les éléments aux indices 1 et 3
