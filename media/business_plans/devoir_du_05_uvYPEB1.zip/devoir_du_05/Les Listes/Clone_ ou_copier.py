ma_liste = [1, 2, 3, 4, 5]
liste_clonee = ma_liste.copy()

print("Liste originale :", ma_liste)
print("Liste clonée :", liste_clonee)
