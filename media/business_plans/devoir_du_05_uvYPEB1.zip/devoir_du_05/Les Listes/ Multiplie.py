def multiplier_chiffres(liste):
    # Initialise le produit à 1 (élément neutre de la multiplication)
    produit = 1

    # Multiplie chaque chiffre de la liste
    for chiffre in liste:
        produit *= chiffre

    return produit

# Exemple d'utilisation
ma_liste = [2, 3, 4, 5]

produit_des_chiffres = multiplier_chiffres(ma_liste)

# Affichage du résultat
print(f"Le produit de tous les chiffres de la liste est : {produit_des_chiffres}")
