def verifier_existence(liste, element):
    # Vérifie si l'élément est dans la liste
    if element in liste:
        return f"L'élément {element} existe dans la liste."
    else:
        return f"L'élément {element} n'existe pas dans la liste."

# Exemple d'utilisation
ma_liste = [10, 20, 30, 40, 50]
element_a_verifier = 30

resultat = verifier_existence(ma_liste, element_a_verifier)
print(resultat)
