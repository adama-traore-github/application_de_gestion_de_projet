def somme_chiffres(nombre):
    # Convertit le nombre en chaîne de caractères et calcule la somme des chiffres
    return sum(int(chiffre) for chiffre in str(nombre))

def somme_chiffres_liste(liste):
    # Calcule la somme des chiffres pour chaque nombre dans la liste
    return [somme_chiffres(nombre) for nombre in liste]

# Exemple d'utilisation
ma_liste = [123, 456, 789]

somme_des_chiffres = somme_chiffres_liste(ma_liste)

# Affichage des résultats
for nombre, somme in zip(ma_liste, somme_des_chiffres):
    print(f"La somme des chiffres de {nombre} est : {somme}")
