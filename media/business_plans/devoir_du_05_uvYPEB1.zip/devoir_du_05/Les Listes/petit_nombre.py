def trouver_plus_petit(liste):
    # Vérifie si la liste est vide
    if not liste:
        return None  # Retourne None si la liste est vide

    # Initialise le plus petit nombre avec le premier élément de la liste
    plus_petit = liste[0]

    # Parcourt la liste pour trouver le plus petit nombre
    for nombre in liste:
        if nombre < plus_petit:
            plus_petit = nombre

    return plus_petit

# Exemple d'utilisation
ma_liste = [34, 12, 5, 78, 23]

plus_petit_nombre = trouver_plus_petit(ma_liste)

# Affichage du résultat
print(f"Le plus petit nombre dans la liste est : {plus_petit_nombre}")
