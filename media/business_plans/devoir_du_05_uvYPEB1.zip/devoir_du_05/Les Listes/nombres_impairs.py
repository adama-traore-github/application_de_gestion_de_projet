def imprimer_nombres_impairs(liste):
    # Filtrer et imprimer les nombres impairs
    impairs = [nombre for nombre in liste if nombre % 2 != 0]
    
    if impairs:  # Vérifie si la liste des nombres impairs n'est pas vide
        print("Les nombres impairs dans la liste sont :")
        for nombre in impairs:
            print(nombre)
    else:
        print("Aucun nombre impair trouvé dans la liste.")

# Exemple d'utilisation
ma_liste = [34, 12, 5, 78, 23, 41, 60]

imprimer_nombres_impairs(ma_liste)
