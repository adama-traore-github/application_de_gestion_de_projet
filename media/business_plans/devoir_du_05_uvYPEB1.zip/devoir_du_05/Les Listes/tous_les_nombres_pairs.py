def imprimer_tous_nombres_pairs(liste):
    # Filtrer et imprimer tous les nombres pairs
    pairs = [nombre for nombre in liste if nombre % 2 == 0]
    
    if pairs:  # Vérifie si la liste des nombres pairs n'est pas vide
        print("Tous les nombres pairs dans la liste sont :")
        for nombre in pairs:
            print(nombre)
    else:
        print("Aucun nombre pair trouvé dans la liste.")

# Exemple d'utilisation
ma_liste = [34, 12, 5, 78, 23, 41, 60]

imprimer_tous_nombres_pairs(ma_liste)
