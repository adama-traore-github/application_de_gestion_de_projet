def valeurs_manquantes_et_supplementaires(liste1, liste2):
    # Convertir les listes en ensembles
    ensemble1 = set(liste1)
    ensemble2 = set(liste2)

    # Trouver les valeurs manquantes et supplémentaires
    manquantes = ensemble1 - ensemble2  # Éléments dans liste1 mais pas dans liste2
    supplementaires = ensemble2 - ensemble1  # Éléments dans liste2 mais pas dans liste1

    return list(manquantes), list(supplementaires)

# Exemple d'utilisation
liste_a = [1, 2, 3, 4, 5]
liste_b = [3, 4, 5, 6, 7, 8]

manquantes, supplementaires = valeurs_manquantes_et_supplementaires(liste_a, liste_b)

# Affichage du résultat
print("Valeurs manquantes dans liste_b par rapport à liste_a :", manquantes)
print("Valeurs supplémentaires dans liste_b par rapport à liste_a :", supplementaires)
