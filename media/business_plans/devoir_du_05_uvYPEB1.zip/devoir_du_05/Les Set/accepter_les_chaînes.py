def contient_toutes_les_voyelles(chaine):
    # Définir les voyelles
    voyelles = set("aeiou")
    
    # Convertir la chaîne en minuscules et créer un ensemble de caractères dans la chaîne
    caracteres = set(chaine.lower())
    
    # Vérifier si toutes les voyelles sont présentes dans l'ensemble de caractères
    return voyelles.issubset(caracteres)

# Exemple d'utilisation
ma_chaine = "Bonjour, le monde!"
resultat = contient_toutes_les_voyelles(ma_chaine)

# Affichage du résultat
if resultat:
    print("La chaîne contient toutes les voyelles.")
else:
    print("La chaîne ne contient pas toutes les voyelles.")
