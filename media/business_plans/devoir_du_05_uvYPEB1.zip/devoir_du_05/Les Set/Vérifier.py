def ont_elements_communs(liste1, liste2):
    # Convertir les listes en ensembles pour une vérification rapide
    ensemble1 = set(liste1)
    ensemble2 = set(liste2)

    # Vérifier si l'intersection des ensembles n'est pas vide
    return not ensemble1.isdisjoint(ensemble2)

# Exemple d'utilisation
liste_a = [1, 2, 3, 4]
liste_b = [4, 5, 6, 7]

resultat = ont_elements_communs(liste_a, liste_b)

# Affichage du résultat
if resultat:
    print("Les deux listes ont au moins un élément en commun.")
else:
    print("Les deux listes n'ont pas d'élément en commun.")
