def elements_communs(liste1, liste2, liste3):
    # Convertir les listes en ensembles
    ensemble1 = set(liste1)
    ensemble2 = set(liste2)
    ensemble3 = set(liste3)

    # Utiliser l'intersection pour trouver les éléments communs
    communs = ensemble1.intersection(ensemble2).intersection(ensemble3)

    return list(communs)

# Exemple d'utilisation
liste_a = [1, 2, 3, 4, 5]
liste_b = [3, 4, 5, 6, 7]
liste_c = [4, 5, 8, 9]

resultat_communs = elements_communs(liste_a, liste_b, liste_c)

# Affichage du résultat
print("Les éléments communs aux trois listes sont :", resultat_communs)
