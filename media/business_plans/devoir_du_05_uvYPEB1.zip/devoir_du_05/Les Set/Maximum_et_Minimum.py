def trouver_maximum_et_minimum(ensemble):
    # Trouver le maximum et le minimum dans l'ensemble
    maximum = max(ensemble)
    minimum = min(ensemble)
    return maximum, minimum

# Exemple d'utilisation
mon_ensemble = {5, 1, 3, 7, 9, 2}

maximum, minimum = trouver_maximum_et_minimum(mon_ensemble)

# Affichage du résultat
print("Le maximum dans l'ensemble est :", maximum)
print("Le minimum dans l'ensemble est :", minimum)
